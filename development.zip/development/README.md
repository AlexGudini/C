### What is this repository for? ###

* Данный репозиторий содержит базу знаний Среды управления проектирования ostis-ситем.

* Техническое задание по проекту на весенний семестр 2018 года [здесь](https://docs.google.com/document/d/1fsSsoXZV_DuHRZ_voW-SX9YCcR6MR54zEtDoqpCTPMM/edit?usp=sharing)

### Who do I talk to? ###

* Repo [owner](https://bitbucket.org/grakova)
* site: http://85.143.221.50:8082